<!DOCTYPE html>
<html>
<head>
	<title>Belgian Cherry Chocolate Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Belgian Cherry Chocolate Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>

<p>Maida 1 3/4 cups<br>

Sugar 2 cups<br>

egg 4 nos<br>

butter 10 tsp<br>

vanilla essence 1 tsp<br>

baking powder 2 tsp<br>

cocoa powder 1/4 cups<br>

salt (as required) 1 tsp<br>

whipping cream 1 tbsp<br>

white chocolate 100 gms<br>

Dark chocolate 100 gms<br>

fresh cream 200 ml<br>

silver edible balls 3 tbsp</p><br>


<b>Instructions -</b><br><br>
<p>01 Vanilla cake recipe:In a bowl mix egg and butter and beat till fluffy and pour half to another bowl.<br>

02
 Mix 1 cup maida,1 cup sugar, 1 tsp baking powder, salt(as required) in a bowl and Add 1 tsp of vanilla essence to that mixture<br>

03
 Add one bowl egg and butter(1 st step) fluffy to 2nd step mixture and fold the batter<br>

04
bake the batter in a preheated oven in 180 degree for 20 minutes.<br>

05
chocolate cake recipe : Mix 3/4 cup maida and 1/4 cup cocoa powder,1 cup sugar, 1 tsp baking powder, salt(as required) in a bowl<br>

06
Add the second bowl egg and butter fluffy to it<br>

07
Fold and bake the batter in a preheated oven in 180 degree for 20 minutes.<br>

08
Cut the cakes into 3 layer each.<br>

09
For icing beat one cup whipping cream till its fluffy.<br>

10
Make white ganache using 100 gm white chocolate with 100 ml fresh cream.Double boil this mix till the chocolate melts into it.<br>

11
Make chocolate ganache using 100 ml dark chocolate with 100 ml fresh cream.Double boil this mix till the chocolate melts into it.<br>

12
On the stand, arrange the cake layers by mixing vanilla and chocolate layer by layer and in between add whipping cream.. and use the white ganache for frosting outside the cake.<br>

13
Decorate using chocolate ganache (as your idea).<br>

14
Decorate with whipping cream and silver edible balls as per your choice and keep in cool place for half an hour. ᐧ</p><br>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/Veps1BnzLr0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>