<!DOCTYPE html>
<html>
<head>
	<title>Eggless Red Velvet Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Eggless Red Velvet Cake Recipe</center></h2><br>

<b>Ingredients -</b>
<b>For Red Velvet Cake</b>
<p>½ cup 150gm unsalted butter, room temperature<br>
1 cup 397gm condensed milk / milkmaid<br>
1½ cup milk (warm)<br>
1 tsp vanilla extract<br>
4 tsp red food colour<br>
1 tsp vinegar<br>
1.5 cup 263gm maida / plain flour / all purpose flour / refined flour<br>
1 tbsp cocoa powder<br>
¾ tsp baking soda<br>
1 tsp baking powder<br>
pinch of salt</p><br>

<b>For Creame Cheese Frosting</b>
<p>250 gm cream cheese (room temperature)<br>
2 tbsp unsalted butter (room temperature)<br>
1 tsp vanilla extract<br>
2 cup icing sugar / powdered sugar</p><br>

<b>For Garnish</b>
<p>3 tbsp chocolate (grated)</p><br><br>



<b>Method</b>
<p>firstly, in a large mixing bowl take ½ cup butter and 1 cup condensed milk.

beat smooth and fluffy till the butter and condensed milk combines well.

further add 1½ cup milk, 1 tsp vanilla extract, 4 tsp red food colour and 1 tsp vinegar.

beat and combine well.

also sieve in 1.5 cup maida, 1 tbsp cocoa powder, ¾ tsp baking soda, 1 tsp baking powder and pinch of salt.

beat the batter on low speed till everything combines well. do not over beat as the cake turns to be hard.

make sure to get flowing consistency batter by adding more milk if required.

meanwhile, preheat the oven to 180°c for 10 minutes and transfer the cake batter to a cake mould (dia: 7 inch, height: 4 inch). make sure to line a butter paper at the bottom to prevent from sticking.

and also tap twice to level up uniformly and remove any air bubbles if present.

bake the cake at 180 degree celsius or 356 degree fahrenheit for 40 minutes. to bake in microwave or cooker check out the notes section below.
easy & moist eggless velvet cake recipe 
cool down the cake completely. also transfer the cake to cooling rack to cool faster</p><br>


<b>cream cheese frosting recipe</b>
<p>firstly, in a large mixing bowl take 250 gm cream cheese and 2 tbsp unsalted butter.

beat them till they turn whitish.

add in 1 tsp vanilla extract and 2 cup icing sugar.

mix well and then beat till the frosting turns smooth and fluffy.

also continue to beat till thick and firm peaks appear to the frosting. add more icing sugar if frosting is watery.</p><br>


<b>layering eggless red velvet cake recipe</b>
<p>firstly, trim the top of cake if there is bulge. also cut the cake in centre dividing into 2 equal half.

place a layer of baked cake on turning table.

furthermore, spread the generous amount of prepared cream cheese frosting.

then place another baked cake.

start spreading frosting over the sides of cake carefully.

also spread generous amount of prepared cream cheese frosting.

then with the help of offset spatula or a knife, spread the prepared frosting evenly and garnish with grated chocolate.

finally, eggless red velvet cake recipe is ready, cut the cake to desired shape and serve. store in refrigerator to serve later.</p>


<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/uG5rhbQbtDM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>