<!DOCTYPE html>
<html>
<head>
	<title>Cosmetic Delight Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Cosmetic Delight Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>

<p> One 8 or 9-inch double layer cake of your choice. (I used this chocolate cake recipe)<br>
 1 batch of buttercream frosting (I used the caramel frosting from the above chocolate cake recipe)<br>
 24 ounces Pink Fondant<br>
 Makeup fondant decorations (you can make these yourself using different colored fondant and/or gum paste or just buy them on Etsy!)<br>
 White Sugar Pearls<br>
 A ruler<br>
 Edible glue<br>
 Paint brush</p><br>


<b>Instructions -</b><br>


<p>First, if you are making your own makeup cake toppers, I suggest you do this the day before assembling the cake so they dry out and are firm. As you can see, the amount and color of toppers you need depends on how you want to decorate the cake. I used lipstick, blush, pencil, etc.<br><br>
Next, assemble your cake. I baked this chocolate cake recipe and made a batch of that caramel frosting. My cake was three layers so it will have some height to it. Frost it roughly.<br>
Freeze the cake briefly so the frosting firms up. Then do another layer of thin frosting around the cake and try to smooth it out. Freeze the cake again as you prepare the fondant.<br><br>
Next, roll out your fondant into a big circle. I used 24 ounce pack of fondant and I think rolled it into a 12-inch circle. Just make sure the circle is wide enough to cover your cake. You can measure the height of the cake to be exact.<br>
Cover the cake with fondant. Smooth out and cut off excess. You can save some of the fondant to make a band and bow. These are optional of course.
For the outside of the cake, I opted for a simple quilt design. Watch the video above to help with this.<br><br>
Once you have your quilting done, use edible glue to attach a pink 2-inch band around the bottom of the cake. Add a bow at the bottom as well.
Using edible glue, attach the white sugar pearls in the intersection of each diamond. Do as many or as little as you wish.
Finally, top the cake with the fondant make up decorations.
</p><br>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/bUCdM3LSIEE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>