<!DOCTYPE html>
<html>
<head>
	<title>Eggless Strawberry Jam Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Eggless Strawberry Jam Cake Recipe</center></h2><br>

<b>Ingredients -</b>
<b>For the Sponge Cake Base:</b>
<p>2 cups all purpose or cake flour<br>
1 1/3 cups sugar<br>
1 1/3 cups soy milk<br>
1/2 cup sunflower oil<br>
2 tablespoons apple cider vinegar<br>
1 1/2 teaspoons baking powder<br>
1/2 teaspoons salt<br>
3 teaspoons vanilla extract</p><br>

<b>For the Strawberry Jam:</b>
<p>2 cups strawberries remove stem and chop in half<br>
3 tablespoons chia seeds<br>
1/2 cup agave syrup<br>
2 tablespoons agar agar</p><br>

<b>For the Topping:</b>
<p>2 cups vegan whipped cream<br>
1 cup strawberries</p><br><br>



<b>Preparation</b>
<b>For the Vanilla Cake:</b>
<p>Preheat the oven to 360˚F. Then line a 7 inch round cake tins with a round piece of parchment paper.
Sift the flour into a bowl.<br>
Add sugar, baking soda and salt and whisk together.<br>
Add soy milk, vegetable oil, vanilla extract, and apple cider vinegar and fold in gently till the ingredients come together. Don't over mix.<br>
Pour the cake batter into the cake tin and bake for around 60 min at 360˚F. To check if cooked, Insert a toothpick into the cake. If it comes out dry the cake is ready. If wet, bake for longer. <br>Let the cake cool completely before cutting it or layering it.</p><br>


<b>For the Strawberry Jam:</b>
<p>Remove the stem from the strawberries, cut them in half and place them in a blender.
Add the chia seeds and the agave syrup.<br>
Blend for a few seconds.<br>
Pour the mix into a sauce pan, bring to simmer and cook on low heat for about 15 minutes.<br>
Let cool down, it will thicken up. If you want the jam thicker we suggest adding 2 tsp of agar agar. Boil the agar agar in the jam for 1 minute while stirring. Let cool down to thicken.</p><br>


<b>For the Whipped Cream:</b>
<p>You can either whip up some ready made vegan whipping cream, or whip together a can of very cold full fat coconut cream with 1/4 cup of icing sugar.</p><br>

<b>To Assemble:</b>
<p>When the cake is cool, cut it in half with a serrated knife add the strawberry jam on top of one of the layers.<br>
Top with the other layer, and cover it completely with the vegan whipped cream. Use a knife or a spatula to spread the whipped cream evenly around the cake.<br>
Decorate the top of the cake as you like. We use some whole strawberries on top.</p>


<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/y2seki8smoM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>