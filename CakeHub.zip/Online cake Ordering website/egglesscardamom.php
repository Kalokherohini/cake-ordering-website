<!DOCTYPE html>
<html>
<head>
	<title>Eggless Cardamom Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Eggless Cardamom Cake Recipe</center></h2><br>

<b>Ingredients -</b>
<p>2 and 1/2 cups cake flour <br>
2 tea spns baking powder<br>
1 tea spn baking soda<br>
1 can 14oz sweetened condensed milk<br>
1 cup orange juice<br>
1/8 tea spn freshly ground cardamom powder<br>
1 cup butter I used salted butter</p><br>

<b>Instructions -</b>
<p>Peel and powder cardamom. Sieve together all purpose flour, corn flour, baking soda and baking powder. Take butter, orange juice, condensed milk and cardamom. Beat well to mix. (It is a good idea to beat butter first and then add other things to avoid splattering!). Then slowly add the flour mix a little at a time and mix well. Add the batter in a greased pan. The batter is pretty thick, but it will bake beautifully. Bake in preheated oven. Let the cake cool and then cut horizontally. Spread some strawberry jam in between(optional). Keep the top layer. Make the icing and decorate the cake (optional step). </p><br>

<p>Preheat oven at 350F for about 10mins.<br>
Grease a baking dish with butter and flour, keep aside.<br>
Sieve together dry ingredients - cake flour, baking powder, baking soda and keep aside.<br>
Take condensed milk, orange juice, cardamom powder, butter in a bowl and beat till mixed.<br>
Add the flour mixture a little at a time and mix till combined.<br>
Bake at 350F for about 40-45mins till a tooth pick inserted in the center comes clean.</p><br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/GdghiT2aL4U" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>