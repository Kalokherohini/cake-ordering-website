<!DOCTYPE html>
<html>
<head>
	<title>Chota Bheem Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Chota Bheem Cake Recipe</center></h2><br>

<b>Ingredients -</b>

<p>400 ml milkmaid<br>
220 gms maida<br>
200 ml water<br>
2 tsp baking powder<br>
1 tsp baking soda<br>
4 tbspn cocoa powder<br>
1/2 tsp chocolate essence<br>
6 tbsp melted butter<br><br>
<b>For icing : </b><br>
4 cups whip cream (Whip till thick)<br>
as needed Piping gel<br>
3-4 drops Blue colour</p><br>



<b>Instructions -</b><br>
<p>Take Maida,baking powder,soda,cocoa powder seive two times and keep a side
Now take milkmaid add butter and beat well mix above Maida mixture add water and beat for 2 to 3 mints at last add essence and mix well.<br>
Take 1 kg cake tin and half kg tin grease and dust it. Divide cake batter in one kg cake tin and half kg tin and bake in otg
Preheat 10 mints on 180° bake for 35 to 40 mints cool it and keep a side
After cooling make sugar water take 2 cups of water add sugar 6tbspn mix it and keep a side<br>
Now take one cake keep on cake board cut from center pour some sugar water and apply whipped cream place cutted cake and pour sugar water again and apply cream
Next place send part of step cake repeat the same process apply whipped cream neatly at last add blue colour to piping gel fill in cone and pour like water flow with the help of cone.<br>
Spread it with pallete knife decorate cake with chota bheem edible photos fixed on tooth pick.
</p>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/TbTfKMMeIWY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>