<!DOCTYPE html>
<html>
<head>
	<title>Chocolate Strawberry Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Chocolate Strawberry Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>
<b>Cake: </b>
<p>3 eggs, at room temperature<br>
1 cup sugar<br>
½ cup vegetable oil or sunflower oil<br>
1 cup plain yogurt<br>
½ cup milk<br>
2 cups all purpose flour<br>
½ cup cocoa powder<br>
2 teaspoons baking powder<br>
1 teaspoon vanilla powder or extract</p><br>

<b>Chocolate Ganache :</b>
<p>160ml heavy cream<br>
160g chocolate chips or chopped chocolate</p><br>

<b>Filling and topping :</b>
<p>1 and ½ cups fresh strawberries<br>
Fresh mint leaves</p><br>


<b>Instructions -</b><br>
<p>Lightly oil two 6'' round spring form cake pans, line their bottoms with parchment paper and set aside.<br>

Preheat oven to 350F (180C).
Beat eggs and sugar with an electric mixer or a hand whisk until creamy.<br><br>
Add in oil,  yogurt and milk. Mix well.
Gradually sift the flour directly into the mixing bowl and mix just until combined. Don't add all of it at one time. Don't over-mix.
Add in cocoa powder, baking powder and vanilla powder. Stir well. Don’t over-mix the batter, just until everything combines.<br><br>

Share the batter into two pans and bake for 30-35 minutes or until a toothpick inserted into the center comes out clean.
Remove them from oven and let them cool in the pan for about 10 minutes. Then remove them from pans carefully. Allow them to cool completely on a cooling rack.
Meanwhile prepare the chocolate ganache.(See the video above).<br><br>
Put chocolate chips in a bowl.
Heat the heavy cream just until it boils and pour it over the chocolate chips. Wait for 2 minutes and stir until smooth.
Let it reach to room temperature.<br><br>
Spread ¼ of your chocolate ganache on the first cake. Wait for about 10 minutes so that the ganache sets a bit.
Slice ½ cup of strawberries lengthwise and place them on the chocolate ganache you spread on the first cake.
Carefully place the second cake on the strawberries, gently press on it just to help it set.<br><br>
Pour the rest of the ganache over it. Wait about 10 minutes and then place the rest of the strawberries as they are on the top.
Place a sprig of fresh mint on the very top.
</p>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/wHkhI8Z9hZM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>