<!DOCTYPE html>
<html>
<head>
	<title>Mango Dry Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Mango Dry Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>

<p>1 cup mango (cubes)<br>
¾ cup 180 grams sugar<br>
½ cup (120 ml) oil<br>
1 tsp vinegar<br>
½ tsp yellow food colour<br>
2 cup (280 grams) maida / plain flour<br>
1 tsp baking powder<br>
¼ tsp baking soda<br>
¼ tsp salt<br>
¼ cup (60 ml) milk</p><br>


<b>Instructions -</b><br><br>

<p>firstly, in a blender take 1 cup mango and ¾ cup sugar.<br>
blend to smooth puree dissolving sugar completely.<br>
transfer the mango puree into large bowl.<br>
add ½ cup oil, 1 tsp vinegar and ½ tsp yellow food colour.<br><br>
using a whisk, mix well making sure everything is well combined.<br>
now place a sieve and add 2 cup maida, 1 tsp baking powder, ¼ tsp baking soda and ¼ tsp salt.<br>
sieve the flour making sure there are no lumps.<br>
mix well using cut and fold method.<br><br>
now add ¼ cup milk and mix until the batter is combined well.<br>
to prepare cake in a pressure cooker add in 1½ cup of salt and close the lid of cooker without keeping the gasket and whistle. heat for 5 to 10 minutes. as a result, gives a preheat oven atmosphere.<br>
now transfer the cake batter to a cake mould (dia: 7 inch, height: 4 inch). make sure to line a butter paper at the bottom to prevent from sticking.
and also tap twice to level up uniformly and remove any air bubbles if present.<br><br>
place the cake pan into preheated cooker.<br>
cover and cook on a medium flame for 45 minutes. you can alternatively, preheat and bake at 180-degree celsius for 45 minutes.<br>
insert a toothpick and check if the cake has baked completely.
cool the cake and then unmould the aam cake.<br>
finally, enjoy eggless mango cake as it is or decorate with frosting.

</p><br>


<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/pTElNOzSyNs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>