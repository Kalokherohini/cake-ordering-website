<!DOCTYPE html>
<html>
<head>
	<title>Barbie Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Barbie Cake Recipe</center></h2><br>

<b>Ingredients -</b>

<p>2 cake mixes made according to package directions<br>
1 Barbie or Barbie-sized Princess Doll<br>
Cream Cheese Frosting</p><br>


<b>Instructions -</b><br>
<p>In a large bowl, make up cake batter for both cake mixes. *Optional - for a more dense and moist cake substitute half of the water for the same amount of sour cream.<br>
Grease and flour a medium and small glass bowl.<br>
Fill with batter until they are a little over 3/4 full. Use remaining batter for cup cakes.<br>
Bake at 325 for about an hour or until the center feels set.<br>

At exactly 7 minutes after you remove the cake from the oven, turn out of bowl onto wax paper. This prevents the cake from sweating and sticking to the bowl.<br>
Stick the cakes in the freezer for a few hours until they are really firm.
Layer the small cake onto the large cake and trim any over hang.<br>
Layer with frosting then decorate with more frosting. Stick your Princess or Barbie in the center of the cake and frost over her upper half to make it look like a dress.
</p>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/K51-kRTSTCk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>