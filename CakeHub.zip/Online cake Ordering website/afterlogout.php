<!DOCTYPE html>
<html>
<head>
	<title>After logout...</title>
	<style type="text/css">
		body {
  font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgmyacc1.jpg');
}

h1{
  color: pink;
}

h3{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}
	</style>
</head>
<body>
	<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6>
  
  <br><br>
  <form>
  	<audio autoplay loop>
      <source src="http://localhost/CSS%20programs/logout%20voice.aac"/>
      <source src="http://localhost/CSS%20programs/logout%20voice.ogg"/>
    </audio>
  </form>
<center><img src="http://www.showroomsalesskills.com/wp-content/uploads/2017/02/Thanks-for-Visiting.png" height="500" width="500"></center>
<br><br>



<center>
<form action="login.php">
	
	<input type="submit" name="log" value="...CLICK HERE TO LOGIN AGAIN...">
</form>
</center>
</body>
</html>