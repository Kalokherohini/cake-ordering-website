<!DOCTYPE html>
<html>
<head>
	<title>Vanilla Almond Dry Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Vanilla Almond Dry Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>

<p><b>Almond Cake:</b><br>

1 cup + 2 tablespoons (150 grams) all purpose flour<br>

1 teaspoon (4 grams) baking powder<br>

1/4 teaspoon (1 gram) salt<br>

7 tablespoons (100 grams) unsalted butter, at room temperature<br>

1/2 cup plus 1 tablespoon (115 grams) granulated white sugar<br>

2 large eggs, at room temperature<br>

2 teaspoons (8 grams) pure vanilla extract<br><br>

<b>Almond Topping:</b><br>

3/4 cup (150 grams) granulated white sugar<br>

7 tablespoons (100 grams) unsalted butter<br>

2 tablespoons cream (can use a heavy or light cream)<br>

1 1/2 cups (150 grams) sliced almonds</p><br>


<b>Instructions -</b><br><br>

<p>Preheat your oven to 350 degrees F (180 degrees C). Butter (or spray with a non stick vegetable spray) a 9 inch (23 cm) springform pan.<br>

In a bowl, sift or whisk together the flour, baking powder, and salt.<br><br>

Next, in the bowl of your electric stand mixer, fitted with the paddle attachment (or with a hand mixer), beat the butter until smooth. Add the sugar and beat until thoroughly mixed together. Add the eggs, one at a time, beating well after each addition. Scrape down the sides and bottom of your bowl as needed. Beat in the vanilla extract. Beat or fold in the flour mixture, mixing just until combined.<br><br>

Pour the batter into your prepared pan, smoothing the top with an offset spatula or the back of a spoon. Bake for about 18 - 20 minutes, or until a toothpick inserted into the center of the cake comes out just clean (you will notice that the cake is just starting to pull away from the sides of the pan).<br><br>

While the cake is baking prepare the Almond Topping. Place all the ingredients in a saucepan and stir, over medium-low heat, until melted and the mixture comes to a boil.<br><br>

As soon as the baked cake is removed from the oven, immediately pour the hot Almond Topping over the cake, smoothing with the back of a spoon or an offset spatula. Return the cake to the oven and bake for a further 18 - 20 minutes or until the topping turns a beautiful golden brown. Place on a wire rack to cool completely before removing the sides of the springform pan. This cake can be covered and stored at room temperature for about two to three days.<br><br>

Makes about 10 servings.

</p><br>


<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/Q_pwpsuVwNw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>