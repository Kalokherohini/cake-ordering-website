<!DOCTYPE html>
<html>
<head>
	<title>Blueberry Dry Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Blueberry Dry Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>

<p>1 cup (130 g) all purpose flour plus 1 teaspoon of flour (plus more for prepping cake pan)<br>
1 teaspoon baking powder<br>
1/2 teaspoon salt (omit if using salted butter)<br>
1/8 teaspoon cinnamon<br>
1/2 cup (4 oz, 113 g, 1 stick) unsalted butter, softened<br>
3/4 cup (160 g) sugar<br>
1/4 teaspoon vanilla extract<br>
2 large eggs<br>
1 teaspoon lemon zest (optional)<br>
2 cups (325 g) blueberries, rinsed and drained (if using frozen blueberries, thaw and drain first)<br>
1 teaspoon lemon juice<br>
Powdered sugar for dusting</p><br>


<b>Instructions -</b><br><br>

<p>Preheat oven and prepare springform pan:<br>
Preheat oven to 350°F. Lightly butter an 8 or 9-inch springform pan and dust with flour. Or use an 8 or 9-inch round cake pan, butter and dust with flour and line the bottom with parchment paper.<br><br>


Mix flour with baking powder and salt:<br>
Vigorously whisk together 1 cup of flour with baking powder, salt, and cinnamon and set aside.<br><br>


Make batter:<br>
Using a mixer, beat the butter on medium high speed for 2 minutes. Add the sugar and beat until light and fluffy, a couple minutes more. Stir in the vanilla extract.

Add the eggs one at a time and beat until well blended. Stir in the lemon zest if using.

Reduce the speed of the mixer to low and slowly add the flour mixture, beating until smooth.<br><br>


Pour the batter into the prepared springform pan.<br><br>


Toss berries with flour and lemon juice, spoon over batter:<br>
Combine the berries with the remaining teaspoon of flour and the lemon juice in a bowl. Spoon the berry mixture over the batter.<br><br>

Bake:<br>
Bake on middle rack in oven for 45 to 55 minutes at 350°F, or until a tester inserted into the center comes out clean.

Remove from oven and let the cake cool in the pan for 10 minutes.

Carefully slide a thin knife around the edges of the cake to release it from the pan.<br><br>


Dust with powdered sugar to serve:<br>
Transfer the cake to a platter, berry side up. Dust the cake with powdered sugar to serve.

</p><br>


<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/bE9TTUr4H0I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>