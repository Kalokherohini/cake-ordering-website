<!DOCTYPE html>
<html>
<head>
	<title>Minnie Mouse Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Minnie Mouse Cake Recipe</center></h2><br>

<b>Ingredients -</b>

<p>Ready-To-Use Gum Paste<br>
Black Icing Color<br>
Copper Icing Color<br>
Creamy Peach Icing Color<br>
Rose Icing Color<br>
Buttercream Frosting<br>
cornstarch<br>
Gum Glue Adhesive</p><br>


<b>Instructions -</b><br>
<p>In advance: Make bow. Tint 6 oz. of gum paste rose. Roll
out 1/8 in. thick. Using Bow Patterns and knife, cut one
bottom and two top sections. Score lines with veining tool
from set following pattern. Let dry on cornstarch-dusted
board. Attach top sections to bottom with gum glue
adhesive.<br>

Also: Make polka dots. Roll out white gum paste 1/16 in.
thick. Cut circles using wide end of tip 2A. Attach to bow
with gum glue adhesive.
And: Make knot. Roll a 1/2 x 2 in. long log of rose gum
paste. Flatten to 3/4 in. wide. Taper one end and attach for
knot with gum glue adhesive.<br><br>

Bake and cool Minnie Mouse cake. Position on foilwrapped cake board cut to fit.<br><br>
Outline facial features with tip 3 and black buttercream
icing. Pipe in eyes with white, mouth and pupils with black
and tongue with peach (smooth with finger dipped in cornstarch).<br><br>
Cover top of head, nose and ears with tip 16 stars in black.
Cover face with tip 16 stars in light copper. Pipe tip 3 dot
eye highlights in white and outline lashes in black.<br><br>
Position bow; prop up with a small amount of icing.
</p>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/FdNVEp1sgUg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>