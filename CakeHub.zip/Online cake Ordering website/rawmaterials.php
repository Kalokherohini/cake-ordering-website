<!DOCTYPE html>
<html>
<head>
  <title>Buy Raw Materials</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

body {font-family: georgia;}
* {box-sizing: border-box;} 

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 40px;
  padding: 0 10px;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0);
}

.container {
  padding: 0 16px;
   color: white;

}


.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
  text-decoration: none;
}
 

.title {
  color: white;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color:  DodgerBlue;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color:  DodgerBlue;
}

  

</style>

<style type='text/css'>
  
  h1 {
    color:pink;
  }

   h2 {
    color:white;
  }

  h6 {
    color:pink;
  }

  body {
  background-image: url('bgimg1.jpg');
}
  
   
</style>
</head>
 
   
 
 
 
 
<h1>Cake Hub - Online Cake Ordering Website</h1><BR><BR>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6>
<br><br>

<h2><CENTER>BUY RAW MATERIALS ONLINE</h2></CENTER><BR><BR><br>

</head>
<body>

   
  
<div class="bg-img"> 
<body bgcolor="BLACK">


  
<div class="row">
  <div class="column">
    <div class="card">


      <center><img src="bakeshake.jpg" style="width:70%"></center>
      <div class="container">
         <center>
        <p class="title"><B>BAKESHAKE</B></p>
      </center>
        
        
       
           <button class="button" onclick ="document.location='https://www.bakeshake.co.in/'"> VISIT WEBSITE </a></button>

          
      </div>
    </div>
  </div>

  <div class="row">
  <div class="column">
    <div class="card">


      <center><img src="bakewala1.jpg"  style="width: 70%"></center>
      <div class="container">
         <center>
        <p class="title"><B>BAKEWALA</B></p>
      </center>
        

 <button class="button" onclick ="document.location='https://www.bakewala.com/'"> VISIT WEBSITE  </a></button>
       
      
      </div>
    </div>
  </div>


 <div class="row">
  <div class="column">
    <div class="card">
      <center><img src="indiamart1.jpg"  style="width:70%"></center>
      <div class="container">
         <center>
        <b><p class="title">INDIAMART</p></b>
      </center>

        
       
        </center>

      <button class="button" onclick ="document.location='https://www.indiamart.com/proddetail/cake-raw-materials-5657267412.html'">VISIT WEBSITE </a></button> 
          
          </div>
      </div>
    </div>
  </div>

<br><br><br><br>

  <div class="row">
  <div class="column">
    <div class="card">
      <center><img src="amazon1.jpg" style="width:70%"></center>
      <div class="container">
        <center>
        
        <p class="title">AMAZON</p>
      </center>
         <button class="button" onclick ="document.location='https://www.amazon.in/Baking-Tools-Accessories/b?ie=UTF8&node=1380182031'">VISIT WEBSITE </a></button> 
          
       
          
          
      </div>
    </div>
  </div>

 <div class="row">
  <div class="column">
    <div class="card">
     <center> <img src="bakerykart1.jpg" style="width:70%"></center>
      <div class="container">
        <center>
        
        <p class="title">BAKERYKART</p>
      </center>
       
       <button class="button" onclick ="document.location='https://www.bakerykart.com/'"> VISIT WEBSITE </a></button> 
          
       
      </div>
    </div>
  </div>
 

  <div class="row">
  <div class="column">
    <div class="card">
     <center> <img src="360cc1.jpg" style="width:70%"></center>
      <div class="container">
        <center>
      
        <p class="title">360CC</p>
      </center>
       
         <button class="button" onclick ="document.location='https://www.360cc.in/Baking-Supplies/27'">VISITE WEBSITE </a></button> 
            
          
      </div>
    </div>
  </div>
 
    </div>
  </div>

 
          
          
      </div>
    </div>
  </div>
 
    </div>
  </div>
 
    </div>
  </div>
 
      </div>
    </div>
  </div>
 
</div>

</body>
</html>