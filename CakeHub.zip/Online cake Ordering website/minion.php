<!DOCTYPE html>
<html>
<head>
	<title>Minions Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Minions Cake Recipe</center></h2><br>

<b>Ingredients -</b>

<p>1 black fondant icing<br>
1 kg Yellow Fondant Icing<br>
1 White fondant<br>
1 red food dye<br>
1 black food dye (to make grey)<br>
1 two halves of Vanilla sponge<br>
1 buttercream icing (of a preferred flavour)<br>
1 jam (of a prefered flavour)</p><br>

<b>vanilla cake ingredients - </b>
<p>450 grams unsalted butter<br>
450 grams sugar<br>
8 eggs<br>
2 tbsp vanilla<br>
450 grams self raising flour<br>
4 tsp baking powder<br>
4 tbsp milk</p><br>

<b>Chocolate Buttercream - </b>
<p>3 tbsp Cocoa<br>
250 grams unsalted butter<br>
250 grams icing sugar</p><br>


<b>Instructions -</b><br>
<p>If you have already made your sponge skip ahead to step 3. For my vanilly sponge: cream together the butter and sugar, before adding the eggs and vanilla- stir well but avoid curdling the butter. Fold in the flour and baking powder and if stiff add the milk. Divide between two 9" tins and bake for 50 minutes. Leave to cool completely before continuing.<br>

To make the Chocolate Buttercream, blend together the butter and icing sugar, add the cocoa powder- stirring until a desired consistency.
Pipe or spread the Butter creamon one half/one of the sponge cakes, carefully placing the other half on top afterwards. Press down on the top sponge a little, using a spatula to neaten the buttercream which will be spilling from the edges. This can be scraped away or used to fill gaps withing the sponge. Place in the fridge for 5-10 minutes so the buttercream can set.<br>

Roll out your yellow Fondant, so that it will fit and cover your cake evenly. Use a jam as 'glue' spreading it all over the cake. Carefully pick the icing up, a rolling pin helps, place it onto the cake. Using your hands lightly rub the top of the cake flattending out the fondant. Continue to rub down the sides of the cake until the cake is layered evenly. Use a sharp knife to cut away excess icing.<br>

Away from the cake, make the following parts to the minions face from the other fondant colours. Add a little drop of black to white fondant to create grey (for the Goggles) red food dye can also be use to create the 'tounge'.cut them using sharp knives, or cutters: I used different size cups as guidelines. place on to a tray lined with cling film. Use my pictures as guidelines.<br>

Place the parts of th face according to the photographs. A little water will work well to stick the parts together.<br>

Roll out the black fondant, and slice into 2 long rectangles, put one either side of the goggle cutting at the bace of the cake.<br>

Other extra decoration you could add include an edge of buttercream at the base of the cake or hair<br>
</p>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/4jPdv15q0qw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>