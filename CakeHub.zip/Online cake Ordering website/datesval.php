<!DOCTYPE html>
<html>
<head>
	<title>Dates and Valnuts Dry Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Dates and Valnuts Dry Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>
<b>Cake :</b>
<p>250 grams pitted dates<br>
65 grams walnuts<br>
240 ml hot boiling water<br>
100 grams butter (1/2 cup) in room temperature<br>
200 grams condensed milk<br>
1 tsp pure vanilla extract<br>
150 grams all purpose flour<br>
1 tsp baking powder<br>
1/2 tsp baking soda<br>
1/4 tsp salt</p><br>


<b>Instructions -</b><br><br>

<p>Pre heat the oven to 350 F<br>

Chop the dates in small pieces and soak them in hot boiling water for 30 to 40 minutes<br>

If there is any extra water after the dates are done soaking, keep the water aside. We will use it later.<br>

Grease a loaf tin / cake pan with butter and line it with some parchment paper, so it is easy for you to remove the cake.<br>

Add butter to a large mixing bowl and and beat it until soft. Next add the condensed milk, vanilla essence to it and beat it again until they are well combined.
<br>
Sift together all the dry ingredients – flour, baking powder, baking soda, salt<br>

Add the dry ingredients to the batter in batches. Mixing them until they are well combined. Do not over mix them.<br>

Now add the dates and the walnuts (reserve some walnuts to add sprinkle on top) little by little and mix gently.<br>

Add the reserve dates water if any to the batter and mix.<br>

Add the batter to the cake pan / loaf tin. Tap the pan 2 to 3 times to knock out anir bubbles if any. Add the reserve walnuts on top for some crunch and bake it for 60 minutes until a tooth pick inserted comes out clean.<br>

Let it cool before you slice the cake.<br>

Serve your date and walnut cake warm or coldᐧ</p><br>


<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/A1nA7uxSpf8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>