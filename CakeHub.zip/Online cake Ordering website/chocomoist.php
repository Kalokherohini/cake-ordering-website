<!DOCTYPE html>
<html>
<head>
	<title>Moist Chocolate Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Moist Chocolate Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>
<b>The Most Amazing Chocolate Cake: </b>
<p>butter and flour for coating and dusting the cake pan<br>
3 cups all-purpose flour<br>
3 cups granulated sugar<br>
1 1/2 cups unsweetened cocoa powder<br>
1 tablespoon baking soda<br>
1 1/2 teaspoons baking powder<br>
1 1/2 teaspoons salt<br>
4 large eggs<br>
1 1/2 cups buttermilk<br>
1 1/2 cups warm water<br>
1/2 cup vegetable oil<br>
2 teaspoons vanilla extract</p><br>

<b>Chocolate Cream Cheese Buttercream Frosting :</b>
<p>1 1/2 cups butter softened<br>
8 oz cream cheese softened<br>
1 1/2 cups unsweetened cocoa powder<br>
3 teaspoons vanilla extract<br>
7-8 cups powdered sugar<br>
about 1/4 cup milk as needed</p><br>


<b>Instructions -</b><br>
<b>The Most Amazing Chocolate Cake :</b>
<p>Preheat oven to 350 degrees Fahrenheit. Butter three 9-inch cake rounds. Dust with flour and tap out the excess.<br>
Mix together flour, sugar, cocoa, baking soda, baking powder, and salt in a stand mixer using a low speed until combined.<br>
Add eggs, buttermilk, warm water, oil, and vanilla. Beat on a medium speed until smooth. This should take just a couple of minutes.<br>
Divide batter among the three pans. I found that it took just over 3 cups of the batter to divide it evenly.<br>
Bake for 30-35 minutes in a 350 degree oven until a toothpick inserted into the center comes out clean.<br>
Cool on wire racks for 15 minutes and then turn out the cakes onto the racks and allow to cool completely.<br>
Frost with your favorite frosting and enjoy! 
</p><br>

<b>Chocolate Cream Cheese Buttercream Frosting</b>
<p>In a large bowl, beat together butter and cream cheese until fluffy. Use a hand mixer or stand mixer for best results
Add in cocoa powder and vanilla extract. Beat until combined.<br>
Beat in powdered sugar, 1 cup at a time. Add milk as necessary to make a spreadable consistency. The frosting should be very thick and will thicken even more if refrigerated.</p>
<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/IYDqmL70lLc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>