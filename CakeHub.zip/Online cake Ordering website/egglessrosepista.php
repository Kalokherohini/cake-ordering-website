<!DOCTYPE html>
<html>
<head>
	<title>Eggless Rose and Pistachio Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Eggless Rose and Pistachio Cake Recipe</center></h2><br>

<b>Ingredients -</b>
<p>Milk – ½ cup<br>
Curd – ½ cup<br>
Vegetable oil – ½ cup<br>
Powdered sugar – ¾ cup<br>
Pistachio/vanilla essence – ½ tsp<br>
All-purpose flour – 1 ¼ cups<br>
Baking soda – ½ tsp<br>
Baking powder – 1 tsp<br>
Salt – a pinch<br>
Ground pistachios – ¼ cup<br>
Green food colour ( optional) – ½ tsp<br><br>
<b>For Frosting:</b><br>
Sweetened heavy whipping cream – 1 cup<br>
Rose essence or edible rosewater – ½ tsp<br>
Pink food colour ( optional)– ¼ tsp<br><br>
<b>For rose milk mixture to soak the cake:</b><br>
Milk – ¼ cup<br>
Condensed milk – 2 tbsp<br>
Rose syrup/ crush – 1 tbsp<br><br>
<b>For decorations/garnish:</b><br>
Chopped pistachios<br>
Rose petals<br>
Silver and green sprinkles</p><br>



<b>Instructions -</b>
<p>Preheat the oven to 180 degree Celsius for 10 to 15 minutes.
Grease a 6 or 7 inch round pan with vegetable oil.
In a clean mixing bowl take curd and milk then beat it to make buttermilk. Then add vegetable oil, powdered sugar, pistachio or vanilla essence then mix it properly with the help of a whisk.<br>
Now shift in all-purpose flour, cornflour, baking soda, baking powder and salt then mix it properly so that the batter is smooth and lump-free.
Then add ground pistachios in the batter. You can also add green food colour which is totally optional.
Switch to a spatula and fold in the batter so that it is well incorporated.<br>
Transfer all the batter into prepared pan. Always tap before putting it inside the oven to avoid air bubbles.
Bake for 25 to 30 minutes in a preheated oven at 180 degree Celsius.
Meanwhile, take sweetened heavy whipping cream add rose essence or edible rose water and beat it for a while then you can add pink food colour which is optional and beat it till stiff peaks.<br>
To make rose milk mixture to soak the cake we will take milk, condensed milk and rose syrup/crush mix it well then keep it aside.
Once the cake is baked do the toothpick test to check the doneness. It should come out clean. Let it cool for 10 minutes then with the help of offset spatula demould the cake and let it cool down completely.
Divide the cake into three layers with the help of a serrated knife, remove the brown layer on the top with the same knife.
To frost cake, take a plate put little cream at the bottom then place one layer on the plate.<br>
Soak the bottom layer of the cake nicely with rose milk mixture then start spreading the rose whipped cream on the bottom layer with an offset spatula.
Place the second layer on top of it and press it properly. Repeat the same process for the next layer.
Then for the last layer again repeat the same process, soak with milk rose syrup and start covering the whole cake with frosting. Cover the sides and top nicely.<br>
To keep it simple but elegant you can take a cake comb and make a pattern on the side and top. Now to decorate we will take chopped pistachios and sprinkle it on the sides of the cake add some sprinkles and rose petals to make it more attractive. Then add some chopped pistachios at the sides of the bottom as well. You can always pipe any designs of your choice to decorate the cake. It is all up to you.<br>
Once completed set the cake in the refrigerator until you serve it.</p><br>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/kupeUv-3aCk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>