<!DOCTYPE html>
<html>
<head>
	<title>Smiley Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Smiley Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>
<b>FROSTING :</b>
<p>6 oz / 120 gr firm tofu<br>
¼ cup coconut butter, softened<br>
½ cup agave or maple syrup<br>
2 tbsp lemon juice<br>
1 tsp pure vanilla extract<br>
½ tsp almond extract (or orange blossom water)<br>
¼ tsp salt<br>
1 cup shredded unsweetened coconut</p><br>

<b>LIQUID CAKE:</b>
<p>2 tbsp almond milk (or another plant milk)<br>
½ tbsp apple cider vinegar<br>
½ cup maple syrup (or agave, coconut nectar, etc.)<br>
1 tsp pure vanilla extract<br>
¼ tsp pure almond extract (or orange blossom water)</p><br>

<b>DRY CAKE:</b>
<p>6 tbsp white rice flour<br>
¼ cup tapioca starch<br>
3 tbsp sweet sticky rice flour/glutinous rice flour<br>
¼ tsp guar gum<br>
¼ tsp baking powder<br>
⅛ tsp baking soda<br>
dash of salt</p><br>

<b>“BUTTER” MIXTURE:</b>
<p>¼ cup cashew butter<br>
¼ cup boiling water</p><br>

<b>CHOCOLATE “FEATURES”:</b>
<p>approx ½ cup melting chocolate (more or less depending on how complex your emoji is and how big you make it)<br>
parchment paper</p><br>



<b>Instructions -</b><br>
<p>Prepare the frosting by combining all the ingredients in a power blender until completely smooth (use the vitamix tamper to help you along, or pause to scrape sides and keep blending until the coconut is incorporated). Transfer into a glass container and freeze until cake is ready to be frosted (or for at least 4-5 hours to let it firm up).
Pre-heat the oven to 350F. Oil a 6″ cake pan. Set aside.<br>
In a small bowl combine the plant milk with vinegar and set aside, allowing it to curdle a little while working on next step.<br>
Combine all dry ingredients in a large mixing bow. Add in all liquid cake ingredients, including the almond vinegar mixture, and mix everything thoroughly to combine.<br>
In a separate bowl combine the cashew butter with the boiled water and stir to thin out and dissolve the cashew butter. Add this to the cake batter and mix everything to combine. Pour the batter into prepared cake pan.<br>
Bake in a preheated oven for approximately 40 mins (until the top is lightly golden and a skewer inserted in the center of the cake comes out dry). Remove from oven and cool on a cooling rack completely before proceeding to frost.<br>
Once cake and frosting are cooled enough, frost cake, and place in the fridge. Prepare the chocolate “features” as per instructions in the post above). Decorate cake and enjoy! Keep it chilled or refrigerated.
</p>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/I1wPn1poB1A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>