<!DOCTYPE html>
<html>
<head>
	<title>Cake Academy...</title>
	<style type="text/css">
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgcontact1.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}
	</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<center><h2>Cake Academy and Decorating Classes</h2></center>
<p><b><center>We are so excited to announce that classes are back and better then ever! Classes are now offered IN STUDIO and VIRTUALLY.</center></b><br><br>
Join the incredibly talented Cake Hub Academy for these creative and fun cupcake and cake classes. Cake Hub has come up with an amazing rotating class schedule so check back here often for new classes and pictures we will be posting! We will teach piping techniques, fondant molding, and so much more.<br><br>
<big>Note : No previous decorating experience needed!</big><br><br><br><br>

<center>
<b><u>DATES & TIMES </u></b><br><br>
May 4th at 5pm MST - IN ACADEMY Icing Flower Cupcake Class<br><br>

May 8th at 5pm MST - IN ACADEMY Mother’s Day Cupcake Class<br><br>

May 13th at 5pm MST - IN ACADEMY Zoo Animal Cupcake Class<br><br>

May 15th at 5pm MST - IN ACADEMY Alpaca Cake Class<br><br>

May 16th at 12pm MST - RESOLUTE BREWING TAP & CELLAR Zoo Animal Cupcake Class<br><br>

May 29th at Noon MST - IN ACADEMY Spring Cupcake Class<br><br>

June 5th at Noon MST - IN ACADEMY Summer Cupcake Class<br><br>

June 8th at 5pm MST - IN ACADEMY Geode Cake Class<br><br>

June 12th at 5pm MST - IN ACADEMY Cheeseburger Cake Class<br><br>

June 19th at Noon MST - IN ACADEMY Father’s Day Cupcake Class<br><br>

June 21st at 6pm MST - VIRTUAL Summer Cupcake Class Partnered with Yelp Colorado<br><br>

June 25th at 5pm MST - IN ACADEMY Zoo Animal Cupcake Class<br><br>

June 29th at 5pm MST - IN ACADEMY Bugs & Critters Cupcake Class<br><br><br><br>

<b><u>HOW DO IN PERSON CLASSES WORK?</u></b><br><br><br>
Contact Us for the class you’re interested in using our contact details.<br><br>

Show up! Wear a mask. Literally - that’s it! We will take care of the rest - we even have your cupcakes or cake pre-baked.<br><br>

We will have seats and tables cleaned and spaced appropriately for each reservation. We have a hand sink and ask that all guests wash hands upon entry as well. You can bring in outside food and beverages from Edgewater Public Market vendors so be sure to see all of our neighbors!<br><br><br><br>

<b><u>HOW DO VIRTUAL CLASSES WORK?</u></b><br><br><br>
Tell your batch - Get the one that corresponds to the class you want to join. Be sure to tell it in plenty of time before the event or class.<br><br>

Bake your cupcakes/cake prior to the event.<br><br>

Login to Zoom and join us for the event - that’s it! No additional charge for joining the class. Just have a pair of scissors and a butter knife handy and be ready to decorate and enjoy! The Zoom link is found on the calendar page for each individual class.<br><br><br><br>

<big>Note : If you want a class reminder or have questions just email us at kateamol3532@gmail.com</big><br><br><br>

<b><u>Contact Details</u></b><br><br>
Name - Akanksha Amol Kate.<br>
Mobile Number - 8745093466<br>
Email ID - kateamol3532@gmail.com<br>
Address - Anand Nagar, Pune.<br>
City - Pune<br>
State - Maharashtra<br>
Pincode - 411051<br><br>
You can also contact us by -
<a href="http://localhost/CSS%20programs/contactus.php">This page</a><br>
</center>

</p>

</body>
</html>