<!DOCTYPE html>
<html>
<head>
	<title>Register Yourself</title>
	
<style>
	table {
		border-collapse: separate;
		border-spacing: 35px 25px;
	}

	body {
  font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgmyacc1.jpg');
}

h1{
  color: pink;
}

h3{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  width: 10%;
}

input[type=reset] {
  background-color: #04AA6D;
  color: white;
  width: 10%;
}

</style>
</head>
<body style="background-color:LightGray;">

	
<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6>


<fieldset><legend><h1 style="color:orange;">Registration Form</h1></legend>

	
	<table>
		<th style="background-color: skyblue;"><b>Personal Details</b></th><br>

      
		<form action="insert.php" method="post">
			<tr>
				<td>
					
		<label>Name: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label></td><td><input type="text" name="fname" placeholder="Akanksha Amol kate" required> &nbsp
	</td>


	<td>
		<label>Mobile: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label></td><td><input type="number" name="mob" placeholder="8744345991" required> &nbsp
		</td>
		
		</tr>
		
		
		<img src="cupcake1.jpg" usemap="#cupcakim1" height="300" width="300" align="right">
<map name="cupcakim1">
<area shape="rect" coords="1,2,297,448">
		
	
	
	
		<tr>
			<td>		
			<label>Password: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label></td><td><input type="Password" name="passw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Enter Password" required> &nbsp
		</td>
		<td>
			<label>Confirm Password: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label></td><td><input type="Password" name="cpassw" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" placeholder="Confirm password" required><br><br>
			</td>
			</tr>
			
		
		

	
	    <tr>
			<td>		
			<label>Email: &nbsp&nbsp&nbsp&nbsp</label></td><td><input type="email" name="eml" placeholder="kateamol3532@gmail.com" title="Please provide E-mail address in the format kateamol3532@gmail.com" required> &nbsp
		</td>
		<td>		
			<label>User Type: &nbsp&nbsp&nbsp&nbsp</label></td><td><input type="text" name="utype" placeholder="user/admin" required> &nbsp
		</td>
		
			</tr>
		
		


		<tr>
			
				<center><th style="background-color: skyblue;"><b>Address Details</b></th></center>
			
		</tr>
	
		
		
		
			<tr>
				<td>
					
				</td>
			</tr>
		
		

	<tr>
		<td>
					
			<label>City: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label></td><td><input type="text" name="cty" placeholder="Pune" required> &nbsp
		</td>
		<td>
			<label>State: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</label></td><td><input type="text" name="stat" placeholder="Maharashtra" required><br><br>
			</td>
			</tr>
		
		
			


		
		
			<tr>
				<td>
					<label>Pincode:</label>
				</td>
				<td>
					<input type="number" name="pinc" placeholder="411051" required> <br>
				</td>
				<td>
					<label>Full Address:</label>
				</td>
				<td>
					<input type="text" name="fadd" placeholder="Anand Nagar" required> <br><br>
				</td>
			</tr>


	
</table>

<img src="cupcake2.jpg" usemap="#cupcakim2" height="300" width="300" align="right">
<map name="cupcakim2">
<area shape="rect" coords="1,2,297,448">
<br><br>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="submit" value="Submit">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
<input type="reset" value="Reset">


</form><br><br>

</map>
</fieldset>
</body>
</html>
