<!DOCTYPE html>
<html>
<head>
	<title>Belgian Cherry Chocolate Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Belgian Cherry Chocolate Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>

<p>2 Whole Eggs<br>
200 grams All Purpose Flour (Maida)<br>
50 grams Butter (Salted)<br>
3 tablespoon Cocoa Powder<br>
80 ml Milk<br>
1/2 cup Heavy whipping cream<br>
200 grams Sugar<br>
1 cup Chocolate chips<br>
1 cup Fresh Cherries<br>
1 teaspoon Baking powder<br>
1 teaspoon Vanilla Extract<br>
Salt , to taste</p><br>


<b>Instructions -</b><br><br>
<p> To begin with the Chocolate Cherry Cake From Scratch recipe first, Cream together the butter(must be at room temperature) and granulated sugar, you can use a whisk or do this in a standing mixture.<br>

Now add eggs and milk to this mix and keep mixing till it looks all combined and become smooth. <br>

Now in another bowl mix flour,baking powder,salt,cocoa powder making sure there are no lumps in the dry mix.<br><br>

To this dry mixture add the wet chocolate mixture and mix it slowly so that they combine well. DON’T over-mix else you will end up with a dense cake.<br>

Now take a cake pan lined with parchment paper and pour in the mix which should be of flowy consistency.<br>

Put the cake pan in the oven and bake at 350C for 15min, keep checking at regular intervals if this is your first time baking.<br><br>

Now for the chocolate ganache, in a heavy bottom pan boil the heavy cream and add the chocolate chips and leave it for 3 minutes. <br>

Now whisk the cream thoroughly so that it becomes a smooth flowy paste and put it in the fridge for a smooth buttery texture<br>

For the caramel, add sugar in a pan with a teaspoon of butter and keep whisking it till it melts completely and turns into golden syrup, do this on low heat to avoid burning the caramel.<br><br>

Check the cake by inserting a toothpick, if it comes out clean it means the cake is cooked completely. <br>

Slice the cake into layers if you wish you and cover the entire cake in ganache , top it with cherries. <br>

Finally add golden strings of caramel by slowing drizzling in the caramel to the cherries and generously coating it.You can add confectionary/icing sugar also if you wish.<br>

Your chocolate Cherry Cake From the Scratch is ready to be served with some espresso. Perfect for the Holiday Season or for a Casual Weekend at Home as an evening Tea Time Snack.</p><br>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/kG6e0V1qBBw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>