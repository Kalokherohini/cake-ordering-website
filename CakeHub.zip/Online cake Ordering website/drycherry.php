<!DOCTYPE html>
<html>
<head>
	<title>Cherry Chocolate Dry Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}
</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Cherry Chocolate Dry Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>
<b>Cake :</b>
<p>• 100g (3.5 oz.) chopped dried cherries<br>
• hot water, for soaking<br>
• 1/2 tsp almond extract<br>
• 200g( 7 oz.) all-purpose flour<br>
• 2 tsp baking soda<br>
• 1/4 tsp salt<br>
• 200g( 7 oz.) granulated sugar or vanilla sugar<br>
• 200g( 7 oz.) yoghurt<br>
• 120ml(4 oz.) vegetable oil<br>
• 2 egg<br>
• A good handful of chocolate chips<br>
• 30g(1oz.) chopped pecans<br>
• More sugar for sprinkling<br>
<br>
<b>Icing</b><br>
• 100g (3.5 oz.) dark chocolate<br>
• 2 tbsp cream</p><br>


<b>Instructions -</b><br><br>

<p>1. Combine cherries, hot water, and almond extract: let stand 20 minutes. Drain cherries, dry on paper towel. Or simply soak them overnight and let it rest in the fridge.<br>
2. In a bowl, combine flour, salt, baking soda, and sugar. Add yogurt, eggs, and oil. Stir well. Fold in cherries and chocolate chips. Pour batter into a greased and floured 8 inch round cake pan.<br>
3. Sprinkle pecans and a little sugar on top of batter.<br>
4. Bake at 200°C or 400°F for 35-40 minutes, or until wooden skewer comes out clean. Cool in pan on wire rack 10 minutes.<br>
5. Melt the chocolate and the cream together. Fill it in a piping bag and pipe it over the cake. Let it set.<br>
6. Serve with vanilla ice cream or whipped cream. ᐧ</p><br>


<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/LgrAwewqO58" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>