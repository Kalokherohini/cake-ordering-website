<!DOCTYPE html>
<html>
<head>
	<title>Cheese Dry Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Cheese Dry Cake Recipe</center></h2><br>

<b>Ingredients -</b><br>

<p>1 1/2 cups unsalted butter, softened (3 sticks)<br>
8 ounces cream cheese, softened<br>
3 cups granulated sugar, divided<br>
6 large eggs<br>
1 tablespoon vanilla extract<br>
1 teaspoon baking powder<br>
1 teaspoon salt<br>
3 cups all-purpose flour (stir in bag, spoon in cup, level)</p><br>


<b>Instructions -</b><br><br>

<p>Set out the butter, eggs, and cream cheese to come to room temperature. Preheat the oven to 325 degrees F. Move one oven rack to the center of the oven and remove any racks above it.<br><br>

Pull out a standard 12-cup capacity bundt pan. Grease the bundt pan with extra butter or shortening, then scoop 1/4 cup sugar into the pan and shake it around until the fat is well coated in sugar. Dump out any excess sugar. Set aside.<br><br>
Place the softened butter and cream cheese in the bowl on an electric. Beat on high until the mixture is totally smooth. Scrape the bowl with a rubber spatula, then add the remaining 2 3/4 cups sugar. Beat on high again for 3-5 minutes to cream the ingredients until very light and fluffy. Scrape the bowl again.
Turn the mixer on low and beat in the eggs, vanilla extract, baking powder, and salt. Then slowly add the flour a little at a time, until fully combined. Once the batter is smooth, turn off the mixer, as to not overmix the batter.<br><br>
Scoop the batter into the prepared pan. Bake on the center rack for 80-90 minutes. After 80 minutes, test the cake by inserting a toothpick deep into the center of the cake. If it comes out clean, take the pound cake out of the oven.<br><br>
Let the cream cheese pound cake rest in the pan for 15 minutes. Then carefully flip the cake onto a platter or baking rack.

</p><br>


<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/yy3R1Pe0jcc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>