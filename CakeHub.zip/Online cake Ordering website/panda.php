<!DOCTYPE html>
<html>
<head>
	<title>Panda Cake Recipe</title>
	<style>
		body {
    font-family: Arial, Helvetica, sans-serif;
  background-image: url('bgrecipe6.jpg');
  color: white;
}

h1{
  color: pink;
}

h2{
  color: pink;
}

h3{
  color: pink;
}

h4{
  color: pink;
}

h5{
  color: pink;
}

h6
{
  color: pink;
}

p{
  color: white;
}

label{
  color: white;
}

a{
  color: orange;
}

</style>
</head>
<body>

<h1>Cake Hub - Online Cake Ordering Website</h1>
<h6>Free Delivery, Great Discounts, Variety Of Products...</h6><br>
<h2><center>Panda Cake Recipe</center></h2><br>

<b>Ingredients -</b>
<b>For White Cream - </b>
<p>Box Of White Cake Mix - 1<br>
Water - 1 Cup<br>
Vegetable Oil -	1/3 Cup<br>
Egg Whites - 4<br>
Sour Cream - 1/4 Cup<br>
Vanilla Pudding Mix - 1/4 Cup</p><br>

<b>For Frosting - </b>
<p>Vegetable Shortening	-1 Cup<br>
Butter - 1/2 Cup<br>
Granulated Sugar - 6 Cups<br>
Milk - 3 tbsp<br>
Vanilla Extract - 1 1/2 tsp<br>
Cocoa Powder - 3 tbsp<br>
Black Food Coloring - 1 Cup</p><br>

<b>For Decorations - </b>
<p>Black Modelling Chocolate - 2 ounce<br>
White Modelling Chocolate - 1 ounce<br>
Pink Modelling Chocolate - 1 ounce</p><br>


<b>Methods -</b><br>
<b>For White Cakes -</b>
<p>At 350 degrees F, preheat the oven.<br>
With butter, brush the pan and spread flour accordingly with round parchment paper.<br>
With Cupcakes cavities brush the muffins. With butter and flour dust brush cupcakes cavities in a muffin tin.<br>
In a large bowl, add cake mix, water, pudding, sour cream, egg whites, and oil. Mix it properly.<br>
In the mixer, beat the mixture for half minutes, until it will become smooth.
With the batter, fill the cupcake cavities.<br>
In the cake pans, divide the batter accordingly.<br>
For 30 minutes, bake the cakes and cupcakes, check by pricking the fork, if the fork comes out with moist crumbs it is ready then.
For 10 minutes, cool them. <br>
To form the cakes in the bear shape, place the cupcakes upside of the cake, so it will look like Panda’s ear.</p><br>

<b>For Frosting -</b>
<p>In the mixer, add shortening, sugar, and butter, beat until it will turn smooth or fluffy.<br>
In the mixer, add vanilla, milk to smooth the frosting. You can add more milk if required.<br>
Add more milk as needed to make the frosting soft enough to pipe through a star tip yet hold its shape.
In a bowl, transfer 2 cups of frosting.<br>
Add cocoa powder, black food coloring, and milk in the small bowl of frosting.</p><br>

<b>For Decorations -</b>
<p>Roll out the black, white, and pink modeling chocolate with a pin.<br>
Cut black modeling chocolate into an oval shape.<br>
In four circles, cut the white modeling chocolate, cut white modeling chocolate in heart shapes, and four circles fro black modeling chocolate.
With a piping gel, attach a white circle with a black one.<br>
On the top of the white circle, attach a black circle and with the edges of a small white heart attach them. Create 4b more eyes in the same process.
Cut heart-shaped nose from black modeling chocolate.<br>
From Pink modeling, cut one heart and one circle.<br>
By using piping gel, attach points of heart with a circle over the top.</p><br>

<b>Decorate The Panda Bear Cakes</b>
<p>By using frosting, attach eyes and nose in the cake.<br>
By using star tips, pipe white frosting on the cakes around eyes and nose. With black frosting pipe the stars over the ears.
Place it in the refrigerator until it will come in use.</p>

<br><br><br>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/BVNyB2ehojI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

</body>
</html>